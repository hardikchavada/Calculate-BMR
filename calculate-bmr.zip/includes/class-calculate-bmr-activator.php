<?php

/**
 * Fired during plugin activation
 *
 * @link       https://testhardik.ml/about/
 * @since      1.0.0
 *
 * @package    Calculate_Bmr
 * @subpackage Calculate_Bmr/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Calculate_Bmr
 * @subpackage Calculate_Bmr/includes
 * @author     Hardik Chavada <hardikb.chavada@gmail.com>
 */
class Calculate_Bmr_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
