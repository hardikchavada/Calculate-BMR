<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://testhardik.ml/about/
 * @since      1.0.0
 *
 * @package    Calculate_Bmr
 * @subpackage Calculate_Bmr/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="main-bg">
   <div class="card">
       <div class="top">
           <h2>Calculate BMR</h2>
       </div>
       <div class="form-area">
        
            <div class="form-group">
                <input type="number" id="height" placeholder="Height in cm" >
            </div>

            <div class="form-group">
                <input type="number" id="weight" placeholder="Weight in kg" >
            </div>

            <div class="form-group">
                <input type="number" id="age" placeholder="Age" >
            </div>

            <div class="form-group gender">
                <label for="gender">Gender:</label>
                <span>Male</span>
                <input type="radio" id="male" name="gender" value="male" checked>
                <span>Female</span>
                <input type="radio" id="female" name="gender" value="female">
            </div>

            <div class="form-group">
                
                <input type="text" id="bmr-value" placeholder="BMR Value is" >
            </div>

            <div class="form-group">
                 <button type="submit" id="" class="btn-submit" onclick="getbmrvalue()">Calculate BMR</button>
            </div>
            
       </div>
   </div>
</div>