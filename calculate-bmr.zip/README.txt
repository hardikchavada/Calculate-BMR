=== Calculate BMR ===
Contributors: hardikchavada
Donate link: https://testhardik.ml/about/
Tags: comments, spam
Requires at least: 4.7
Tested up to: 5.6
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will help you to add BMR calculator to your Pages/Posts. Add the following shortcode wherever you want to display the BMR form [bmr_shortcode]

== Description ==

A complete mobile responsive BMR calculator for your website. You need to add [bmr_shortcode] shortcode into your pages / posts and it will display the BMR calculator in front-end.

A few notes about the sections above:



== Installation ==

1. Upload `calculate-bmr` plugin to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add shortcode [bmr_shortcode] directly into your pages/posts 

== Frequently Asked Questions ==
= Are there any extra settings? =
Currently there are not extra settings for this version. You just need to add the shortcode [bmr_shortcode] into your pages/posts

= Are there translations? =
Not yet.


== Upgrade Notice ==

= 1.1 =
Future Updates will have more designs & features.

== Screenshots ==

1. screenshot-1.png
2. screenshot-2.png


== Changelog ==

= 1.0 =
* A complete mobile responsive BMR calculator.


= 0.5 =
* Basic BMR calculator for desktop view.
